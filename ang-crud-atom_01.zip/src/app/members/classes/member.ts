export class Member {
  id: string;
  doi: string;
  nombre: string;
  avatar: any;
  fecha_de_ingreso: string;
  genero: string;

  constructor(doi, nombre, fecha, genero) {
    this.doi = doi;
    this.nombre = nombre;
    this.fecha_de_ingreso = fecha;
    this.genero = genero;
  }
}
