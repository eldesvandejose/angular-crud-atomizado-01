export class Member {
  id: string;
  dni: string;
  nombre: string;
  avatar: any;
  fecha_de_ingreso: string;

  constructor(dni, nombre, fecha) {
    this.dni = dni;
    this.nombre = nombre;
    this.fecha_de_ingreso = fecha;
  }
}
