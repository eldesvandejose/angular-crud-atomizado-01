import { Component, OnInit } from '@angular/core';

// Declaramos las variables para jQuery
declare var jQuery: any;
declare var $: any;

@Component({
  selector: 'aca-member-list',
  templateUrl: './member-list.component.html',
  styleUrls: ['./member-list.component.css']
})
export class MemberListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $(document).prop('title', 'Formulario de miembro');
    $('.menuLink').removeClass('active');
    $('#MembersMenuLink').addClass('active');
    $('#MembersListMenuLink').addClass('active');
  }
}
