import { Component, OnInit } from '@angular/core';

// Declaramos las variables para jQuery
declare var jQuery: any;
declare var $: any;

@Component({
  selector: 'aca-member-form',
  templateUrl: './member-form.component.html',
  styleUrls: ['./member-form.component.css']
})
export class MemberFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $(document).prop('title', 'Formulario de miembro');
    $('.menuLink').removeClass('active');
    $('#MembersMenuLink').addClass('active');
    $('#MemberFormMenuLink').addClass('active');
  }
}
